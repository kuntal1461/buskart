package com.buskart.busmanagementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusKartBusManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
