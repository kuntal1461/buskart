package com.buskart.searchservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusKartSearchServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusKartSearchServiceApplication.class, args);
	}

}
