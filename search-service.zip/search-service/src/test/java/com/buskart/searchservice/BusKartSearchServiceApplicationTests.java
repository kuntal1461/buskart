package com.buskart.searchservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusKartSearchServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
